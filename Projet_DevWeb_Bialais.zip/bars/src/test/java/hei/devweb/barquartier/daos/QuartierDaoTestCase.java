package hei.devweb.barquartier.daos;

public class QuartierDaoTestCase {

}
